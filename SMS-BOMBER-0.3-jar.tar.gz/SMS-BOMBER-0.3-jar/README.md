# John's Sms Bomber
A very, very simple sms bomber written in python and java. 
I realized that this repo was getting some decent traffic from google which means there are some non-devs finding this, so for this reason, I made the code even cleaner and easier to config. If you have no idea what to do with this, and were looking for a simple program with UI, well, you're going to want to google "how to run python on windows/mac"; However, Mac already comes with python. If you have a Mac, just download the .py file here to Desktop, open terminal and run ```cd Desktop``` then ```python JohnsTextBomber.py``` after you've edited the CONFIG of course  
  
### DESKTOP APPLICATION FOR N00BS  
download: https://github.com/jdleo/SMS-BOMBER/releases/tag/v0.1-jar  
you MUST have JRE installed (google it) for this to run. You MUST fill in all the fields appropriately. If you have an issue with the application, make a github account and file an issue on this repository, and Ill fix it. Thanks  
(if you don't trust putting your email information, I even posted all the source code here. You can look through it if you know how to read java code, and see that there's no malicious intent. Read "important" header at the bottom of this README. same thing applies to the java version as well.  
  
### CONFIG
If you have no idea what an smtp server is, and you're not using gmail, check this link:   https://www.arclab.com/en/kb/email/list-of-smtp-and-pop3-servers-mailserver-list.html  
  
You'll notice that you need the target email address. Here is a cool website:  
http://freecarrierlookup.com  
Type in number, and it will resolve it to an mms email that you can paste in config  
  
### Important:  
You must have support for "less secure apps" set to "turn on" on your Gmail. Here is the link to do so: https://www.google.com/settings/security/lesssecureapps  
  
### Have fun!
  

